"""
generate_manifest.py — Generate v3_manifest.sha256 in standard sha256sum format.
================================================================================
Recursively computes the SHA-256 digest of every file in the repository
(excluding .git, __pycache__, .venv, and the output manifest file itself) so
anyone downloading the Archive.org release archive can verify codebase integrity
via `sha256sum -c v3_manifest.sha256`.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

EXCLUDED_DIRS = frozenset({".git", "__pycache__", ".venv", "venv", "data"})
MANIFEST_NAME = "v3_manifest.sha256"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def build_manifest(root: Path) -> list[str]:
    entries: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in EXCLUDED_DIRS for part in rel.parts):
            continue
        if rel.name == MANIFEST_NAME or rel.name == ".env" or rel.suffix == ".zip":
            continue
        digest = sha256_file(path)
        posix_rel = rel.as_posix()
        entries.append(f"{digest}  {posix_rel}")
    return entries


def main() -> None:
    root = Path(__file__).resolve().parent
    lines = build_manifest(root)
    out_path = root / MANIFEST_NAME
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    print(f"Wrote {len(lines)} SHA-256 entries to {out_path.name}")


if __name__ == "__main__":
    main()
