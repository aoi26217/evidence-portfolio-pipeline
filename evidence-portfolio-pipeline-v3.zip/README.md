# Evidence Portfolio Pipeline (v3 — Adversarially Hardened Release)

A computational-journalism ETL pipeline that classifies pain-care and
drug-policy news coverage against a fixed 12-tag framework, builds a
provisional evidence graph, and enforces cryptographically signed
human verification before anything is treated as fact.

**The one rule:** everything the model produces is `llm_provisional`.
Evidence becomes citable only through the signed human review in
`src/verify.py`. There is no other door.

## Architecture (v3 Hardened)

```
 corpus/*.txt ──► enqueue_corpus (clean, sha256 identity, atomic .tmp->replace
                      │           archive write, atomic SQLite enqueue_chunked)
                      │           [src/text_cleaning.py, src/checkpoint.py]
                      ▼
              ┌─ producer ─────────────── pending chunks only (exact resume)
              │        asyncio.Queue (bounded → backpressure)
              │  ┌──────────┬──────────┬──────────┐
              └─►│ worker 1 │ worker 2 │ worker N │   [pipeline_orchestrator.py]
                 └────┬─────┴────┬─────┴────┬─────┘   (crash-isolated workers)
                      ▼          ▼          ▼
              AdaptiveRateController (ONE shared instance: debounced AIMD on
              P99 + vLLM /metrics; deadlock-safe 10% retry budget)
                      │                               [rate_controller.py]
                      ▼
              LLM (RunPod vLLM ── or MockLLMClient)   [llm_client.py]
                      │ raw text
                      ▼
              extract_and_repair ─► enforce_schema ─► enforce_framework
              (fences, truncation,   (dict/type guard, (SCOPE pair rule +
               dup keys — recorded)   tag dedupe)       E_MISSING_QUOTES)
                      │                               [json_repair.py,
                      ▼                                extraction_prompt.py]
              verify_quotes (normalized verbatim-substring + min-length check)
                      │                    │ discrepancy
                      ▼                    ▼
              checkpoint (per CHUNK,   triage_queue.jsonl ─► src/verify.py
              persistent SQLite WAL)   (human review; pre-verified, HMAC-signed,
                      │                 hash-chained decisions)
                      ▼                               [audit_verifier.py]
              graph_out/<article>.json  ─►  Neo4j via parameterized UNWIND
              (quarantines unverified        (hard 3 MB byte ceiling, :Entity
               triage errors; whitelisted)    indexed MATCH, sanitized props)
                                                      [neo4j_loader.py]
```

PDF sources: `src/ocr_fallback.py` (per-page scanned-page detection at
<100 chars, 300-DPI pytesseract fallback with preserved line boundaries,
per-page audit log) feeds the same enqueue path.

## What's New in v3 (Adversarial Security & Scale Hardening)

1. **Tamper-Proof HMAC-SHA256 Verification Log (`src/audit_verifier.py`):**
   - **Signing-Oracle Defense:** `SignedVerificationLog` verifies the entire existing hash and HMAC chain on initialization before permitting any new entry to be appended or signed.
   - **Strict Anchor & Truncation Protection:** `verify_log` enforces a 16-hex-character minimum on `anchored_head`, validates JSON object structure and field types on every line, and detects 0-byte wipes, mid-log deletions, reorderings, and stale-anchor rollbacks.
2. **Exact-Resume State Integrity (`src/checkpoint.py`, `src/pipeline_orchestrator.py`):**
   - **Crash-Window Immunity:** Archive files are written via PID-scoped temporary files and atomic `.replace()` *before* committing a single atomic `enqueue_chunked` SQLite transaction (`ON CONFLICT` self-healing if a prior run was hard-killed).
   - **Zero Event-Loop Connection Churn:** `CheckpointStore` maintains a persistent SQLite connection configured once with `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=NORMAL`, and `PRAGMA foreign_keys=ON`.
3. **Resilient vLLM Concurrency & Loop Isolation (`src/rate_controller.py`, `src/pipeline_orchestrator.py`):**
   - **Debounced AIMD & Starvation-Free Retry Budget:** `penalize()` is debounced across `window_seconds` so concurrent timeout spikes do not collapse concurrency in a single tick. Request timestamps are recorded immediately on slot acquisition, and retry-slot starvation is prevented when no primary workers are active.
   - **Worker Crash Isolation & Clean Shutdown:** Unhandled worker exceptions are trapped and recorded per chunk (`worker_crash:...`) without aborting `asyncio.gather()`, and HTTP/metrics sessions close deterministically in `finally` blocks.
4. **Neo4j Injection, OOM & Full-Scan Defenses (`src/neo4j_loader.py`):**
   - **Secondary Property & Epistemic Whitelists:** `_sanitize_props` strips reserved system keys (`id`, `source_file`, `epistemic_status`, etc.) and enforces primitive/homogeneous-array values; `_check_epistemic` strictly whitelists epistemic statuses.
   - **Hard Byte-Capped Batching & Indexed Matching:** `dynamic_batches` enforces a strict 3 MB transaction ceiling regardless of row count, and all nodes carry a shared `:Entity` label with a uniqueness constraint so relationship loading uses indexed `MATCH (a:Entity {id: ...})` lookups instead of $O(E \times N)$ full-graph scans.
5. **Hardened Quote & Framework Validation (`src/extraction_prompt.py`, `src/json_repair.py`):**
   - Normalizes typographic curly quotes/dashes in `verify_quotes`, blocks trivial substring injections, enforces `E_MISSING_QUOTES` when content tags lack quotes, and prevents unrelated chunks (`tags: []`) from flooding human triage.

## Installation & Integrity Verification

```bash
# 1. Verify archive integrity against the v3 SHA-256 manifest
sha256sum -c v3_manifest.sha256
# (or regenerate/check via Python: python generate_manifest.py)

# 2. Set up environment (Python 3.10+ required)
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# optional extras: pip install tiktoken langdetect json-repair neo4j pymupdf pytesseract pillow
cp .env.example .env    # fill in RunPod endpoint + key
python -m src.test_redesign          # 18 checks, no network needed
```

## Configuration

Everything lives in `src/config.py`: the 12-tag vocabulary (11 content
tags + the `SCOPE_LOCAL`/`SCOPE_NATIONAL` pair), model endpoint (env:
`RUNPOD_BASE_URL`, `RUNPOD_API_KEY`, `RUNPOD_MODEL`), chunking knobs,
worker count, and all paths (override with `PIPELINE_DATA_DIR`;
signing key defaults to `~/.pipeline/audit_key`, override with
`PIPELINE_AUDIT_KEY`).

## Running

```bash
# Extraction (resumable; re-running is always safe)
python -m src.pipeline_orchestrator corpus/ --workers 8
python -m src.pipeline_orchestrator corpus/ --mock       # no network

# Human verification (the only path from provisional to citable)
python -m src.verify keygen
python -m src.verify queue
python -m src.verify review
python -m src.verify head      # anchor this hash OUTSIDE the pipeline
python -m src.verify check --anchor <16_char_hex>

# Neo4j load (after extraction; parameterized, whitelisted, byte-capped)
python -c "from neo4j import GraphDatabase; from src.neo4j_loader import *; \
import json, pathlib; d=GraphDatabase.driver('bolt://localhost:7687', \
auth=('neo4j','password')); setup_constraints(d); \
[ (load_nodes(d, g['nodes']), load_edges(d, g['edges'])) \
  for g in (json.loads(p.read_text()) for p in pathlib.Path('data/graph_out').glob('*.json')) ]"
```

## Concurrency Math

Llama 4 Scout (17B active, FP8) on one H100 under vLLM continuous
batching sustains roughly 2,500–5,000 output tok/s (verify on your own
pilot). At ~350 output tokens per classification, that completes ~7–14
requests/s. Little's law: concurrency ≈ throughput × latency; for a 5 s
P99 target that puts the healthy operating point around 15–40 in-flight
requests. The controller **starts at 16** and finds the true ceiling via
AIMD (+1/window on health, ×0.6 on congestion, debounced per window),
steered by observed P99 and vLLM's `num_requests_waiting` /
`gpu_cache_usage_perc`. Retries are capped at 10% of the last minute's
offered load, which converts a retry herd into a queue without starving
workers when primary slots drain. The point of the controller is that
this paragraph's estimates don't need to be right.

Cost reality check (18k articles, ~2.5 chunks each): pure compute is a
few H100-hours — **\$8–32**. Human verification at 20% × 2 min/article is
**~120 hours**. The reviewer experience, not the GPU bill, is the
binding constraint; `verify.py` is designed around that.

## Ethical & Bias Disclosure Guidelines

This pipeline classifies coverage of taper harms, veteran suicide,
patient abandonment, and drug policy — topics where framing itself is
contested. The following are commitments, not decoration:

1. **Nothing provisional is ever cited.** Every extracted item carries
   `epistemic_status: llm_provisional` until a named human signs an
   approval with a typed rationale. Downstream quotability gates must
   WHITELIST trusted statuses, never blacklist provisional ones.
2. **Measure the extractor's bias; don't assert its neutrality.** Before
   the full run, hand-label a calibration set (~20 chunks per tag,
   stratified by outlet lean using an external media-bias rating).
   Report per-tag precision/recall AND per-tag assignment rates
   conditioned on outlet lean. Probe the largest gaps with
   counterfactual pairs (same paragraph, actor names swapped). Publish
   the numbers — including the unflattering ones — in the report's
   methods section, with the measured extraction error rate from
   ongoing triage sampling.
3. **Verbatim evidence only.** Quotes that fail the character-for-
   character source check are quarantined and triaged, never published.
   Quotes from OCR'd pages carry an `ocr` flag; reviewers compare
   against the page image, not the OCR text.
4. **Personal accounts are people.** PERSONAL_ACCOUNT evidence
   describing suicidality or medical harm is handled under the project's
   source-protection norms: no republication of identifying details
   beyond what the original outlet published, and human review of every
   such item before any use.
5. **The audit trail must survive its own author.** Decisions are
   HMAC-signed with a key kept apart from the extraction host, and the
   session head hash is anchored outside the pipeline after every review
   session. `python -m src.verify check --anchor <hex>` detects
   modification, forgery, deletion, insertion, and truncation.
6. **Disclose the machinery.** The published report states: corpus size
   and selection, the model and prompt version, repair and triage rates,
   the human verification rate, and this pipeline's role — machine
   nominates, human verifies.

## Repository Layout

```
├── generate_manifest.py        # recursive SHA-256 manifest generator
├── v3_manifest.sha256          # cryptographic checksums for all release files
├── src/
│   ├── config.py               # 12-tag vocabulary, endpoints, paths, knobs
│   ├── text_cleaning.py        # pre-clean, O(W) token-aware chunking, RTL routing
│   ├── json_repair.py          # extraction/repair, schema, retry mutation
│   ├── extraction_prompt.py    # system prompt, SCOPE rule, normalized quote check
│   ├── llm_client.py           # RunPodClient + MockLLMClient
│   ├── rate_controller.py      # shared debounced AIMD controller + retry budget
│   ├── checkpoint.py           # persistent SQLite WAL, atomic enqueue, exact resume
│   ├── pipeline_orchestrator.py# crash-isolated async producer-consumer loop
│   ├── neo4j_loader.py         # byte-capped UNWIND, :Entity index, prop sanitizer
│   ├── ocr_fallback.py         # line-preserving per-page PDF OCR with audit log
│   ├── audit_verifier.py       # pre-verified HMAC-SHA256 log + tamper detector
│   ├── verify.py               # human review CLI (the only door)
│   └── test_redesign.py        # 18 checks incl. mock end-to-end run
```
